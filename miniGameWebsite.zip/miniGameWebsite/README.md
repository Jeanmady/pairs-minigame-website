Jean Mady ECM1417
Azure VM link: ecm1417@ml-lab-4d78f073-aa49-4f0e-bce2-31e5254052c7.ukwest.cloudapp.azure.com:65428/GameWebsite/miniGameWebsite

Features-------------
Landing Page:
- All functionality working 
- navbar has hover effect when hovering over a selection on nav bar will turn white

registration page:
- All functionality working
- Avater generator using complex 
- Neat tab bar used to toggle through face skin and eyes

Pairs game page:
- Medium game done
- 3D flipping anuimation when cards turn over
- Emojis generated random everytime from provided img assets
- 10 cards
- score board + timer
- score calculated using timer and guesses multiplier so as incorrect guesses/time decreses , guess multiplier/time multiplier decreases + stock 20 for a correct match

Leaderboard page:
- All functionality implemented using a json file
