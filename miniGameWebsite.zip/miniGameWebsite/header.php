<!--Header code including navbar and opening div-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Minigame Website</title>
</head>
<body>
    <nav>
        <div class="topnav">
            <a class="active" href="index.php">Home</a>
            <a href="registration.php" class="split">Play pairs</a>
            <a href="registration.php" class="split">Register</a>
        </div>
    </nav>

    <div class="main">